
const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");
const path = require("path");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const bookingSchema = new mongoose.Schema({
  passenger: { type: String, required: true, trim: true },
  from: { type: String, required: true, trim: true },
  to: { type: String, required: true, trim: true },
  date: { type: String, required: true },
  seats: { type: Number, required: true, min: 1 }
});

const Booking = mongoose.model("Booking", bookingSchema);

app.get("/api/bookings", async (req, res) => {
  try {
    const bookings = await Booking.find().sort({ _id: -1 });
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ error: "Database unavailable. Check MongoDB connection." });
  }
});

app.post("/api/bookings", async (req, res) => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return res.status(503).json({
        error: "MongoDB is not connected. Check the database connection."
      });
    }

    const booking = await Booking.create({
      passenger: req.body.passenger,
      from: req.body.from,
      to: req.body.to,
      date: req.body.date,
      seats: Number(req.body.seats)
    });

    res.status(201).json(booking);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put("/api/bookings/:id", async (req, res) => {
  try {
    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      {
        passenger: req.body.passenger,
        from: req.body.from,
        to: req.body.to,
        date: req.body.date,
        seats: Number(req.body.seats)
      },
      { new: true, runValidators: true }
    );

    if (!booking) {
      return res.status(404).json({ error: "Booking not found" });
    }

    res.json(booking);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete("/api/bookings/:id", async (req, res) => {
  try {
    const booking = await Booking.findByIdAndDelete(req.params.id);

    if (!booking) {
      return res.status(404).json({ error: "Booking not found" });
    }

    res.json({ message: "Booking deleted successfully" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

async function startServer() {
  if (!process.env.MONGO_URI) {
    console.error("ERROR: MONGO_URI is missing from .env");
    process.exit(1);
  }

  try {
    await mongoose.connect(process.env.MONGO_URI, {
      serverSelectionTimeoutMS: 10000
    });

    console.log("MongoDB Connected Successfully");

    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => {
      console.log(`Server running at http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error("MongoDB connection failed:", err.message);
    console.error("Check Atlas URI, database credentials, DNS, and Network Access.");
    process.exit(1);
  }
}

startServer();
