
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Student {
  id: number;
  name: string;
  regno: string;
  course: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {

  students: Student[] = [];

  name: string = '';
  regno: string = '';
  course: string = '';

  editId: number | null = null;

  constructor() {
    this.loadStudents();
  }

  // READ: Load students from browser storage
  loadStudents(): void {
    if (typeof localStorage !== 'undefined') {
      const data = localStorage.getItem('students');

      if (data) {
        try {
          this.students = JSON.parse(data);
        } catch {
          this.students = [];
        }
      } else {
        this.students = [];
      }
    }
  }

  // SAVE: Store students in browser storage
  saveData(): void {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(
        'students',
        JSON.stringify(this.students)
      );
    }
  }

  // CREATE and UPDATE
  saveStudent(): void {
    if (
      !this.name.trim() ||
      !this.regno.trim() ||
      !this.course
    ) {
      alert('Please fill all fields');
      return;
    }

    if (this.editId !== null) {

      // UPDATE existing student
      this.students = this.students.map(s =>
        s.id === this.editId
          ? {
              id: this.editId!,
              name: this.name.trim(),
              regno: this.regno.trim(),
              course: this.course
            }
          : s
      );

      alert('Student updated successfully');

    } else {

      // CREATE new student
      this.students.push({
        id: Date.now(),
        name: this.name.trim(),
        regno: this.regno.trim(),
        course: this.course
      });

      alert('Student registered successfully');
    }

    this.saveData();
    this.clearForm();
  }

  // EDIT: Load selected student into the form
  editStudent(student: Student): void {
    this.name = student.name;
    this.regno = student.regno;
    this.course = student.course;
    this.editId = student.id;
  }

  // DELETE: Remove student
  deleteStudent(id: number): void {
    if (confirm('Do you want to delete this student?')) {

      this.students = this.students.filter(
        student => student.id !== id
      );

      this.saveData();

      if (this.editId === id) {
        this.clearForm();
      }

      alert('Student deleted successfully');
    }
  }

  // CLEAR FORM
  clearForm(): void {
    this.name = '';
    this.regno = '';
    this.course = '';
    this.editId = null;
  }

}
