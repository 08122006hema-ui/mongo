
const soap = require("soap");

const url = "http://localhost:4001/queueService?wsdl";

soap.createClient(url, (err, client) => {
  if (err) {
    console.log(err);
    return;
  }

  client.GetQueue({ id: 1 }, (err, result) => {
    if (err) {
      console.log(err);
    } else {
      console.log(result);
    }
  });
});

