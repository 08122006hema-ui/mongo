from lxml import etree

parser = etree.XMLParser(
    load_dtd=True,
    dtd_validation=True
)

try:
    etree.parse("books.xml", parser)
    print("DTD validation successful!")
    print("Occurrence indicators tested:")
    print("+ = One or more")
    print("* = Zero or more")
    print("? = Zero or one")
except Exception as e:
    print("Validation failed:")
    print(e)
