from lxml import etree

parser = etree.XMLParser(
    load_dtd=True,
    dtd_validation=True
)

try:
    etree.parse("books.xml", parser)
    print("External DTD validation successful!")
except Exception as e:
    print("Validation failed:", e)