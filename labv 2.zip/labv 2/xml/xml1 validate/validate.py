from lxml import etree

try:
    parser = etree.XMLParser(dtd_validation=True)
    etree.parse("courses.xml", parser)

    print("XML file is VALID.")
    print("Internal DTD validation successful.")

except etree.XMLSyntaxError as e:
    print("XML file is INVALID.")
    print(e)
