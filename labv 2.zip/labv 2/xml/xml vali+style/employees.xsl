<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:output method="html" indent="yes"/>

    <xsl:template match="/">
        <html>
            <head>
                <title>Employee Management</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        margin: 30px;
                        background-color: #f4f7f4;
                    }
                    h1 {
                        text-align: center;
                        color: darkgreen;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        background-color: white;
                    }
                    th, td {
                        border: 1px solid gray;
                        padding: 12px;
                        text-align: left;
                    }
                    th {
                        background-color: lightgreen;
                    }
                </style>
            </head>
            <body>
                <h1>Employee Management</h1>
                <table>
                    <tr>
                        <th>Employee ID</th>
                        <th>Name</th>
                        <th>Department</th>
                        <th>Salary</th>
                    </tr>

                    <xsl:for-each select="employees/employee">
                        <tr>
                            <td>
                                <xsl:value-of select="@empid"/>
                            </td>
                            <td>
                                <xsl:value-of select="name"/>
                            </td>
                            <td>
                                <xsl:value-of select="department"/>
                            </td>
                            <td>
                                <xsl:value-of select="salary"/>
                            </td>
                        </tr>
                    </xsl:for-each>
                </table>
            </body>
        </html>
    </xsl:template>

</xsl:stylesheet>
