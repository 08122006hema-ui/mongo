<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet
    version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:template match="/">
        <html>
        <head>
            <title>Books Collection</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #eef6ff;
                    padding: 20px;
                }

                h2 {
                    color: navy;
                    text-align: center;
                }

                table {
                    width: 100%;
                    border-collapse: collapse;
                    background-color: white;
                }

                th {
                    background-color: navy;
                    color: white;
                    padding: 12px;
                }

                td {
                    border: 1px solid gray;
                    padding: 10px;
                    text-align: center;
                }

                tr:nth-child(even) {
                    background-color: #dcecff;
                }
            </style>
        </head>

        <body>
            <h2>Books Collection</h2>

            <table>
                <tr>
                    <th>Book ID</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Price</th>
                </tr>

                <xsl:for-each select="books/book">
                    <tr>
                        <td>
                            <xsl:value-of select="@id"/>
                        </td>
                        <td>
                            <xsl:value-of select="title"/>
                        </td>
                        <td>
                            <xsl:value-of select="author"/>
                        </td>
                        <td>
                            <xsl:value-of select="price"/>
                        </td>
                    </tr>
                </xsl:for-each>

            </table>
        </body>
        </html>
    </xsl:template>

</xsl:stylesheet>