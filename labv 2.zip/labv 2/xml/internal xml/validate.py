from lxml import etree

parser = etree.XMLParser(
    load_dtd=True,
    dtd_validation=True
)

tree = etree.parse("books.xml", parser)

print("Internal DTD validation successful!")
print(etree.tostring(
    tree,
    pretty_print=True,
    encoding="unicode"
))
